import React from "react";
import Links from "./pages/Links";
import Footer from "./pages/Footer";


function App() {
  return (

    <div >
        <Links />
        <Footer/>


    </div>
  );
}

export default App;
